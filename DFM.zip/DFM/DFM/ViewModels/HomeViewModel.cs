﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DFM.Models;

namespace DFM.ViewModels
{
    public class HomeViewModel
    {
        public string Title { get; set; }

        public List<Furniture> Furnitures { get; set; }
    }
}
